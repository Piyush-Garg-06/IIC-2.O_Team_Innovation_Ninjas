package com.anand.agrimarket.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch

enum class TraderSection { HOME, ORDER, TRANSACTION, HELP, CART }
data class TraderCartItem(val name: String, val price: Int, var quantity: Int)

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun TraderDashboard(onLogout: () -> Unit) {
    androidx.activity.compose.BackHandler(enabled = true) { }

    val drawerState = androidx.compose.material3.rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var currentSection by remember { mutableStateOf(TraderSection.HOME) }
    val cartItems = remember { mutableStateListOf<TraderCartItem>() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "AgriMarket",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge
                )

                var selectedItem = remember { mutableStateOf(0) }
                val items = listOf(
                    "Home" to Icons.Filled.Home,
                    "Order" to Icons.Filled.ReceiptLong,
                    "Transaction" to Icons.Filled.SwapHoriz,
                    "Cart" to Icons.Filled.ShoppingCart,
                    "Help" to Icons.Filled.HelpOutline
                )

                items.forEachIndexed { index, pair ->
                    NavigationDrawerItem(
                        icon = { Icon(pair.second, contentDescription = pair.first) },
                        label = { Text(pair.first) },
                        selected = selectedItem.value == index,
                        onClick = {
                            selectedItem.value = index
                            currentSection = when (pair.first) {
                                "Home" -> TraderSection.HOME
                                "Order" -> TraderSection.ORDER
                                "Transaction" -> TraderSection.TRANSACTION
                                "Cart" -> TraderSection.CART
                                else -> TraderSection.HELP
                            }
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "Traders Dashboard",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(imageVector = Icons.Filled.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                    },
                    actions = {
                        TextButton(onClick = onLogout) { Text("Logout", color = Color.White) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F2C59),
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                when (currentSection) {
                    TraderSection.HELP -> TraderHelpSection(modifier = Modifier.fillMaxSize().padding(16.dp))
                    TraderSection.TRANSACTION -> TraderTransactionsSection(modifier = Modifier.fillMaxSize().padding(16.dp))
                    TraderSection.ORDER -> TraderOrdersSection(modifier = Modifier.fillMaxSize().padding(16.dp))
                    TraderSection.CART -> TraderCartSection(modifier = Modifier.fillMaxSize().padding(16.dp), cartItems = cartItems)
                    else -> {
                        TraderHomeSection(
                            modifier = Modifier.fillMaxSize().padding(16.dp),
                            onAddToCart = { name, price ->
                                val existing = cartItems.indexOfFirst { it.name == name }
                                if (existing >= 0) {
                                    val current = cartItems[existing]
                                    cartItems[existing] = current.copy(quantity = current.quantity + 1)
                                } else {
                                    cartItems.add(TraderCartItem(name, price, 1))
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TraderHelpSection(modifier: Modifier = Modifier) {
    val name = rememberSaveable { mutableStateOf("") }
    val email = rememberSaveable { mutableStateOf("") }
    val message = rememberSaveable { mutableStateOf("") }

    Column(modifier = modifier) {
        Text(text = "Help & Support", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))

        Text(text = "Contact Us", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
        Text(text = "Email: support@agrimarket.com")
        Text(text = "Office: AgriMarket HQ, New Delhi, India")
        Text(text = "Working Hours: Mon - Sat (9:00 AM - 6:00 PM)")

        Spacer(modifier = androidx.compose.ui.Modifier.height(16.dp))
        Text(text = "Send us a message:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))

        OutlinedTextField(
            value = name.value,
            onValueChange = { name.value = it },
            label = { Text("Your Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
        OutlinedTextField(
            value = email.value,
            onValueChange = { email.value = it },
            label = { Text("Your Email") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
        OutlinedTextField(
            value = message.value,
            onValueChange = { message.value = it },
            label = { Text("Your Message") },
            modifier = Modifier.fillMaxWidth().height(120.dp)
        )
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))
        Button(onClick = { /* TODO: send message */ }) {
            Text("Send")
        }
    }
}

@Composable
private fun TraderTransactionsSection(modifier: Modifier = Modifier) {
    data class Txn(val payer: String, val amountRs: Int, val date: String)

    val txns = listOf(
        Txn("GreenFresh Foods", 12500, "2025-09-15"),
        Txn("AgroCity Mart", 7800, "2025-09-14"),
        Txn("Urban Wholesale", 15420, "2025-09-12"),
        Txn("FreshBite Retail", 9400, "2025-09-10"),
        Txn("Farm2Table", 21000, "2025-09-08")
    )

    Column(modifier = modifier) {
        Text(text = "Recent Transactions", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))

        androidx.compose.foundation.lazy.LazyColumn {
            items(txns) { t ->
                androidx.compose.material3.Card(
                    colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFFF7FAFF)),
                    modifier = Modifier.fillMaxSize().padding(vertical = 6.dp)
                ) {
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxSize().padding(12.dp)
                    ) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Filled.SwapHoriz,
                            contentDescription = null,
                            tint = Color(0xFF0F2C59)
                        )
                        Spacer(modifier = androidx.compose.ui.Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = t.payer, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(text = t.date, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Text(
                            text = "Rs ${t.amountRs}",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF1B5E20)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TraderOrdersSection(modifier: Modifier = Modifier) {
    data class Purchase(val product: String, val quantityKg: Int, val rateRsPerKg: Int, val date: String)

    val purchases = listOf(
        Purchase("Tomatoes", 200, 22, "2025-09-15"),
        Purchase("Onions", 150, 26, "2025-09-14"),
        Purchase("Potatoes", 300, 18, "2025-09-13"),
        Purchase("Wheat", 500, 30, "2025-09-12"),
        Purchase("Rice", 400, 34, "2025-09-11")
    )

    Column(modifier = modifier) {
        Text(text = "Recent Purchase", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))

        androidx.compose.foundation.lazy.LazyColumn {
            items(purchases) { p ->
                androidx.compose.material3.Card(
                    colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFFFFFBF2)),
                    modifier = Modifier.fillMaxSize().padding(vertical = 6.dp)
                ) {
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxSize().padding(12.dp)
                    ) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Filled.ReceiptLong,
                            contentDescription = null,
                            tint = Color(0xFF6D4C41)
                        )
                        Spacer(modifier = androidx.compose.ui.Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = p.product, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(text = p.date, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                            Text(text = "Qty: ${p.quantityKg} kg", style = MaterialTheme.typography.bodyMedium)
                            Text(text = "Rate: Rs ${p.rateRsPerKg}/kg", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TraderHomeSection(modifier: Modifier = Modifier, onAddToCart: (String, Int) -> Unit) {
    data class CatalogItem(val name: String, val price: Int, val imageRes: Int)
    val items = listOf(
        CatalogItem("Tomatoes", 24, com.anand.agrimarket.R.drawable.tomato),
        CatalogItem("Onions", 28, com.anand.agrimarket.R.drawable.onion),
        CatalogItem("Potatoes", 20, com.anand.agrimarket.R.drawable.potato),
        CatalogItem("Wheat", 32, com.anand.agrimarket.R.drawable.wheat),
        CatalogItem("Rice", 34, com.anand.agrimarket.R.drawable.rice),
        CatalogItem("Bajra", 26, com.anand.agrimarket.R.drawable.bajra),

        CatalogItem("Toor Dal", 85, com.anand.agrimarket.R.drawable.toor),
        CatalogItem("Urad Dal", 95, com.anand.agrimarket.R.drawable.urad)
    )

    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
        columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(2),
        modifier = modifier,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
    ) {
        items(items) { item ->
            androidx.compose.material3.Card {
                androidx.compose.foundation.layout.Column(modifier = Modifier.padding(8.dp)) {
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(id = item.imageRes),
                        contentDescription = item.name,
                        modifier = Modifier.fillMaxSize().height(120.dp)
                    )
                    Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
                    Text(text = item.name, style = MaterialTheme.typography.titleMedium)
                    Text(text = "Rs ${item.price}/kg", color = Color.Gray)
                    Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
                    AnimatedAddToCartButton {
                        onAddToCart(item.name, item.price)
                    }

                }
            }
        }
    }
}

@Composable
private fun TraderCartSection(
    modifier: Modifier = Modifier,
    cartItems: MutableList<TraderCartItem>
) {
    val address = rememberSaveable { mutableStateOf("") }

    // 💡 Calculate totals
    val itemTotals = cartItems.map { it.name to (it.price * it.quantity) }
    val grandTotal = itemTotals.sumOf { it.second }

    Column(modifier = modifier) {
        Text(text = "Cart", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(12.dp))

        if (cartItems.isEmpty()) {
            Text("Your cart is empty")
        } else {
            androidx.compose.foundation.lazy.LazyColumn(
                modifier = Modifier.weight(1f, fill = false)
            ) {
                items(cartItems) { c ->
                    androidx.compose.material3.Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        androidx.compose.foundation.layout.Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            androidx.compose.foundation.layout.Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = c.name,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Rs ${c.price}/kg",
                                    color = Color.Gray
                                )
                                Text(
                                    text = "Qty: ${c.quantity}"
                                )
                                Text(
                                    text = "Subtotal: Rs ${c.price * c.quantity}",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1B5E20)
                                )
                            }

                            IconButton(onClick = { cartItems.remove(c) }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Remove from cart",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "Billing", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))

            // 🧾 Show billing breakdown
            Column(modifier = Modifier.fillMaxWidth()) {
                itemTotals.forEach { (name, total) ->
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                    ) {
                        Text(name)
                        Text("Rs $total")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                ) {
                    Text("Total", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Rs $grandTotal", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1B5E20))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = address.value,
                onValueChange = { address.value = it },
                label = { Text("Address") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = { /* TODO: place order */ },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF254A30)
                )
            ) {
                Text("Post Order", color = Color.White)
            }
        }
    }
}



@Composable
fun AnimatedAddToCartButton(
    onClick: () -> Unit
) {
    var clicked by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (clicked) 1.2f else 1f,
        animationSpec = androidx.compose.animation.core.tween(300),
        label = "scaleAnim"
    )

    val scope = rememberCoroutineScope()

    Button(
        onClick = {
            clicked = true
            onClick()
            scope.launch {
                kotlinx.coroutines.delay(300)
                clicked = false
            }
        },
        modifier = Modifier.graphicsLayer(
            scaleX = scale,
            scaleY = scale
        )
    ) {
        Icon(Icons.Filled.ShoppingCart, contentDescription = "Cart")
        Spacer(Modifier.width(6.dp))
        Text("Add to Cart")
    }
}
