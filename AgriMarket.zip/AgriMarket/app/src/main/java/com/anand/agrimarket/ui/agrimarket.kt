
package com.anand.agrimarket.ui
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.anand.agrimarket.ui.theme.signupfarmer
import com.anand.agrimarket.ui.theme.signuptrader

enum class screens(val title: String) {
    Home("homescreen"),
    LoginFarmer("loginasfarmer"),
    LoginTrader("logintrader"),
    SignupFarmer("signupfarmer"),
    SignupTrader("signuptrader"),
    FarmerDashboard("farmerdashboard"),
    TraderDashboard("traderdashboard"),
    FAQ("faqscreen")
}

@Composable
fun agrimarket() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = screens.Home.name) {

        // Home Screen
        composable(screens.Home.name) {
            homescreen(onfaqclick = { navController.navigate(screens.FAQ.name) },
                onfarmerclick = {navController.navigate(screens.LoginFarmer.name)},
                ontraderclick = {navController.navigate(screens.LoginTrader.name)})
        }

        // Farmer Login
        composable(screens.LoginFarmer.name) {
            com.anand.agrimarket.ui.theme.loginfarmer(
                onBack = { navController.popBackStack() },
                onlogin = {navController.navigate(route= screens.FarmerDashboard.name)},
                onCreateNew = { navController.navigate(screens.SignupFarmer.name) }
            )
        }

        // Trader Login
        composable(screens.LoginTrader.name) {
            logintrader(
                onBack = { navController.popBackStack() },
                onlogin = {navController.navigate(route= screens.TraderDashboard.name)},
                onCreateNew = { navController.navigate(screens.SignupTrader.name) }
            )
        }

        // Signup Farmer
        composable(screens.SignupFarmer.name) {
            signupfarmer(
                onBack = { navController.popBackStack() },
                onSignUp = { navController.navigate(screens.FarmerDashboard.name) }
            )
        }

        // Signup Trader
        composable(screens.SignupTrader.name) {
            signuptrader(
                onBack = { navController.popBackStack() },
                onSignUp = { navController.navigate(screens.TraderDashboard.name) }
            )
        }

        // Farmer Dashboard
        composable(screens.FarmerDashboard.name) {
            FarmerDashboard(
                onLogout = {
                    navController.navigate(screens.Home.name) {
                        popUpTo(screens.Home.name) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )

        }

        // Trader Dashboard
        composable(screens.TraderDashboard.name) {
            TraderDashboard(
                onLogout = {
                    navController.navigate(screens.Home.name) {
                        popUpTo(screens.Home.name) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // FAQ Screen
        composable(screens.FAQ.name) {
            faq(onBack = { navController.popBackStack() })
        }
    }
}

