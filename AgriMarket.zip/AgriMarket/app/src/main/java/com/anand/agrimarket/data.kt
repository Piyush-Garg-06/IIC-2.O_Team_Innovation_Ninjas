package com.anand.agrimarket

data class Order(
    val items: List<Map<String, Any>> = emptyList(),
    val address: String = "",
    val totalAmount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)
