package com.anand.agrimarket.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.ui.res.painterResource
import com.anand.agrimarket.R
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import kotlinx.coroutines.delay
import kotlin.random.Random
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.Divider

enum class Section { HOME, PRODUCT, ORDER, REPORT, HELP }

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun FarmerDashboard(onLogout: () -> Unit) {
    androidx.activity.compose.BackHandler(enabled = true) {
        // Block back press to prevent leaving dashboard via system back
    }

    val drawerState = androidx.compose.material3.rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    var currentSection by remember { mutableStateOf(Section.HOME) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "AgriMarket",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge
                )

                var selectedItem by remember { mutableStateOf(0) }
                val items = listOf(
                    "Home" to Icons.Filled.Home,
                    "Product" to Icons.Filled.ShoppingCart,
                    "Order" to Icons.Filled.ReceiptLong,
                    "Report" to Icons.Filled.BarChart,
                    "Help" to Icons.Filled.HelpOutline
                )

                items.forEachIndexed { index, pair ->
                    NavigationDrawerItem(
                        icon = { Icon(pair.second, contentDescription = pair.first) },
                        label = { Text(pair.first) },
                        selected = selectedItem == index,
                        onClick = {
                            selectedItem = index
                            currentSection = when (pair.first) {
                                "Home" -> Section.HOME
                                "Product" -> Section.PRODUCT
                                "Order" -> Section.ORDER
                                "Report" -> Section.REPORT
                                else -> Section.HELP
                            }
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "Farmer's Dashboard",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(imageVector = Icons.Filled.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                    },
                    actions = {
                        TextButton(onClick = onLogout) { Text("Logout", color = Color.White) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F2C59),
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                when (currentSection) {
                    Section.REPORT -> ReportImagesSection(modifier = Modifier.fillMaxSize().padding(8.dp))
                    Section.ORDER -> OrdersSection(modifier = Modifier.fillMaxSize().padding(8.dp))
                    Section.PRODUCT -> ProductSection(modifier = Modifier.fillMaxSize().padding(16.dp))
                    Section.HELP -> HelpSection(modifier = Modifier.fillMaxSize().padding(16.dp))
                    else -> HomeSection(modifier = Modifier.fillMaxSize().padding(16.dp))
                }
            }
        }
    }
}

@Composable
private fun ReportImagesSection(modifier: Modifier = Modifier) {
    val images = listOf(
        R.drawable.graph1,
        R.drawable.graph2,
        R.drawable.graph3,
        R.drawable.graph4,
        R.drawable.graph5
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(1),
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(images) { resId ->
            Image(
                painter = painterResource(id = resId),
                contentDescription = null,

                modifier = Modifier.height(200.dp)
                    .fillMaxWidth()
                    .aspectRatio(1f)
            )
            Spacer(modifier= Modifier.height(5.dp))
        }
    }
}

@Composable
private fun OrdersSection(modifier: Modifier = Modifier) {
    data class Order(
        val orderId: String,
        val productName: String,
        val quantityKg: Int,
        val buyerName: String,
        val pricePerKgRs: Int,
        val totalPriceRs: Int,
        val deliveryDate: String,
        val status: String
    )

    val orders = listOf(
        Order("ORD-1001", "Tomatoes", 250, "Arjun Traders", 20, 5000, "2025-09-18", "Pending"),
        Order("ORD-1002", "Onions", 300, "FreshMart", 24, 7200, "2025-09-19", "Delivered"),
        Order("ORD-1003", "Potatoes", 150, "CityBazaar", 18, 2700, "2025-09-20", "Pending"),
        Order("ORD-1004", "Wheat", 500, "AgroBuy", 28, 14000, "2025-09-22", "Delivered"),
        Order("ORD-1005", "Rice", 400, "DailyNeeds", 30, 12000, "2025-09-25", "Pending")
    )

    LazyColumn(modifier = modifier) {
        items(orders) { order ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F7F7)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = order.orderId, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Product: ${order.productName}")
                    Text(text = "Quantity: ${order.quantityKg} kg")
                    Text(text = "Buyer: ${order.buyerName}")
                    Text(text = "Price/kg: Rs ${order.pricePerKgRs}")
                    Text(text = "Total: Rs ${order.totalPriceRs}")
                    Text(text = "Delivery: ${order.deliveryDate}")
                    Text(text = "Status: ${order.status}", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun ProductSection(modifier: Modifier = Modifier) {
    data class Product(val name: String, val ratePerKg: String)

    val products = remember { mutableStateListOf<Product>() }
    val productName = rememberSaveable { mutableStateOf("") }
    val productRate = rememberSaveable { mutableStateOf("") }

    Column(modifier = modifier) {
        Text(text = "My Product", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = productName.value,
            onValueChange = { productName.value = it },
            label = { Text("Product Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = productRate.value,
            onValueChange = { productRate.value = it.filter { ch -> ch.isDigit() } },
            label = { Text("Rate (Rs/kg)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {
            if (productName.value.isNotBlank() && productRate.value.isNotBlank()) {
                products.add(Product(productName.value.trim(), productRate.value.trim()))
                productName.value = ""
                productRate.value = ""
            }
        },modifier = Modifier.height(50.dp)) {
            Text("Add Product", fontSize = 22.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Products", style = MaterialTheme.typography.titleMedium, fontSize = 25.sp)
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn {
            itemsIndexed(products) { index, item ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = item.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, fontSize = 25.sp)
                        }
                        Text(text = "Rs ${item.ratePerKg}/kg", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(end = 8.dp),
                            fontSize = 25.sp)
                        IconButton(onClick = { products.removeAt(index) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HelpSection(modifier: Modifier = Modifier) {
    val name = rememberSaveable { mutableStateOf("") }
    val email = rememberSaveable { mutableStateOf("") }
    val message = rememberSaveable { mutableStateOf("") }

    Column(modifier = modifier) {
        Text(text = "Help & Support", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(12.dp))

        Text(text = "Contact Us", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Email: support@agrimarket.com")
        Text(text = "Office: AgriMarket HQ, New Delhi, India")
        Text(text = "Working Hours: Mon - Sat (9:00 AM - 6:00 PM)")

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Send us a message:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = name.value,
            onValueChange = { name.value = it },
            label = { Text("Your Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = email.value,
            onValueChange = { email.value = it },
            label = { Text("Your Email") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = message.value,
            onValueChange = { message.value = it },
            label = { Text("Your Message") },
            modifier = Modifier.fillMaxWidth().height(120.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = { /* TODO: send message */ }) {
            Text("Send")
        }
    }
}

@Composable
private fun HomeSection(modifier: Modifier = Modifier) {
    data class MarketItem(val product: String, var rate: Int, var lastUpdated: String)

    val dateFormat = remember { SimpleDateFormat("HH:mm, dd MMM", Locale.getDefault()) }
    val items = remember {
        mutableStateListOf(
            MarketItem("Tomatoes", 22, dateFormat.format(Date())),
            MarketItem("Onions", 28, dateFormat.format(Date())),
            MarketItem("Potatoes", 20, dateFormat.format(Date())),
            MarketItem("Wheat", 30, dateFormat.format(Date())),
            MarketItem("Rice", 34, dateFormat.format(Date()))
        )
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60 * 60 * 1000L)
            val now = dateFormat.format(Date())
            // Simulate market rate changes
            items.forEachIndexed { index, item ->
                val delta = Random.nextInt(-3, 4)
                val newRate = (item.rate + delta).coerceAtLeast(1)
                items[index] = item.copy(rate = newRate, lastUpdated = now)
            }
        }
    }

    Column(modifier = modifier) {
        Text(text = "Live Market Rates", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(12.dp))
        // 3-column: Product | Rate (Rs/kg) | Last Updated
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F0F0))) {
            Row(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                Text("Product", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text("Rate (Rs/kg)", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text("Last Updated", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn {
            items(items) { it ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 4.dp)) {
                    Text(it.product, modifier = Modifier.weight(1f))
                    Text("Rs ${it.rate}", modifier = Modifier.weight(1f))
                    Text(it.lastUpdated, modifier = Modifier.weight(1f))
                }
                Divider()
            }
        }
    }
}