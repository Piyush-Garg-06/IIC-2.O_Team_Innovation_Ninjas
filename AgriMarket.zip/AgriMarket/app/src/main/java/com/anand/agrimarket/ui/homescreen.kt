package com.anand.agrimarket.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.statusBarsPadding
import com.anand.agrimarket.R
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController


@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun homescreen(onfarmerclick:()-> Unit={},
               ontraderclick:()-> Unit= {},
               onfaqclick:()-> Unit ={}) {
    val darkBlue = Color(0xFF0F2C59)
    val darkGreen = Color(0xFF254A30)
    val traderOrange = Color(0xFFB7410E)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AgriMarket",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = { onfaqclick() }) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = "FAQ",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = darkBlue,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        content = {
            LazyColumn(modifier = Modifier.padding(it)) {
                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(R.drawable.farmer2),
                            contentDescription = "donation",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp)
                                .clipToBounds(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }


                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "LOGIN AS",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = darkBlue,
                            modifier = Modifier
                                .padding(vertical = 16.dp)
                                .align(Alignment.Center)
                        )

                    }
                }


                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Button(
                            onClick = { onfarmerclick() },
                            modifier = Modifier
                                .height(60.dp)
                                .width(150.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = darkGreen)
                        ) {
                            Text(text = "Farmer", fontSize = 22.sp)
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Button(
                            onClick = { ontraderclick() },
                            modifier = Modifier
                                .height(60.dp)
                                .width(150.dp)
                        ) {
                            Text(text = "Trader", fontSize = 22.sp)
                        }
                    }
                }

                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "How AgriMarket Works:",
                            color = darkGreen,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(start = 18.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Farmers Section
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AnimatedArrow(color = darkGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Farmers", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(" • List Produce\n • View Real-Time Prices\n • Manage Sales", modifier = Modifier.padding(start = 32.dp))

                        Spacer(modifier = Modifier.height(12.dp))

                        // Traders Section
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AnimatedArrow(color = traderOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Traders", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(" • Find Reliable Suppliers\n • Forecast Demand\n • Streamline Procurement", modifier = Modifier.padding(start = 32.dp))

                        Spacer(modifier = Modifier.height(12.dp))

                        // Outcome Section
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AnimatedArrow(color = darkBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Outcome", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(" • Fair Prices\n • Transparent Transactions\n • Efficient Supply Chains", modifier = Modifier.padding(start = 32.dp))
                    }

                }

                item {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        // Card for Farmers
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = darkGreen)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "For Farmers",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "->Direct digital marketplace connection with local buyers\n->Live price discovery with daily updates\n->Transparent pricing with fair trade policies\n->Digital supply chain tools for transport & storage",
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Benefits:",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White
                                )
                                Text(
                                    text = "->Higher profits with direct sales\n->Better decision-making using real-time data\n->Trust and transparency in transactions\n->Reduced post-harvest losses",
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Card for Traders
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = darkBlue)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "For Traders",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "->Direct verified connection with farmers\n->Transparent digital price updates\n->Elimination of intermediaries reduces costs\n->Data-driven insights for demand forecasting",
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Benefits:",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White
                                )
                                Text(
                                    text = "->Reliable and consistent supply of produce\n->Fair and predictable pricing\n->Higher profit margins through cost savings\n->Efficient inventory and demand planning",
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun AnimatedArrow(modifier: Modifier = Modifier, color: Color = Color.Black) {
    val infiniteTransition = rememberInfiniteTransition(label = "arrow")
    val offsetX by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arrowOffset"
    )

    Icon(
        imageVector = Icons.Default.ArrowForward, // material arrow icon
        contentDescription = "arrow",
        tint = color,
        modifier = modifier.offset(x = offsetX.dp)
    )
}



